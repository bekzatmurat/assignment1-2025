import java.util.Scanner;

public class Problem_9 {
    public static int BinomialCoef(int n, int k) {
        if (k == 0 || k == n) { return 1; }
        return BinomialCoef(n-1,k-1)+BinomialCoef(n-1,k);
    }
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=scanner.nextInt();
        int k=scanner.nextInt();
        System.out.println(BinomialCoef(n, k));
        int s=scanner.nextInt();
        int m=scanner.nextInt();
        System.out.println(BinomialCoef(s, m));
    }
}